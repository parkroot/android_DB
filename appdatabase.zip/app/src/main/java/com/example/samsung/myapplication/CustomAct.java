package com.example.samsung.myapplication;

import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class CustomAct extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom);
    }

    public void onClickButton(View v) {
        EditText txt = null;
        txt = (EditText)findViewById(R.id.editText8);
        String sql = txt.getText().toString();

        SQLiteDatabase db = openOrCreateDatabase(
                "test.db",
                SQLiteDatabase.CREATE_IF_NECESSARY,
                null );

        db.execSQL(sql);

        finish(); //Call this when your activity is done and should be closed.
    }
}