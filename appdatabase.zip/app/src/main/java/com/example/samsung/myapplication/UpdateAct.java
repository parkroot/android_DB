package com.example.samsung.myapplication;

import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class UpdateAct extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
    }

    public void onClickButton(View v) {
        EditText txt = null;
        txt = (EditText) findViewById(R.id.editText4);
        String sid = txt.getText().toString();
        txt = (EditText) findViewById(R.id.editText5);
        String name = txt.getText().toString();
        txt = (EditText) findViewById(R.id.editText6);
        String age = txt.getText().toString();

        String sql = "UPDATE peple2 SET name='" + name + "', age=" + age + " WHERE sid=" + sid + ";" ;

        SQLiteDatabase db = openOrCreateDatabase(
                "test.db",
                SQLiteDatabase.CREATE_IF_NECESSARY,
                null);

        db.execSQL(sql);

        finish(); //Call this when your activity is done and should be closed.
    }
}